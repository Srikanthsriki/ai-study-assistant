"""
Reusable Gemini AI service.

All AI-powered features (chat, summarizer, question generator, quiz
generator, document Q&A) go through the functions in this file instead of
duplicating API-calling code across routes.

The GEMINI_API_KEY is read from the environment on the backend only —
it is never sent to or accessible from the frontend.
"""
import json
import re
import google.generativeai as genai
from app.config import settings

# Configure the SDK once with the API key from environment variables
if settings.GEMINI_API_KEY:
    genai.configure(api_key=settings.GEMINI_API_KEY)

MODEL_NAME = "gemini-2.0-flash"

SYSTEM_INSTRUCTION = (
    "You are an educational AI study assistant. Explain concepts clearly and "
    "accurately. Adapt explanations to the student's level. When solving "
    "problems, explain the reasoning step by step rather than giving "
    "unexplained answers. Use examples where helpful. For exam preparation, "
    "provide concise and structured answers. If the student asks for "
    "programming help, provide clean code and explain it. If information is "
    "uncertain, clearly say so rather than inventing facts."
)


class GeminiServiceError(Exception):
    """Raised when the Gemini API cannot fulfill a request."""
    pass


def _get_model(system_instruction: str = SYSTEM_INSTRUCTION):
    if not settings.GEMINI_API_KEY:
        raise GeminiServiceError(
            "GEMINI_API_KEY is not configured on the server. "
            "Add it to backend/.env to enable AI features."
        )
    return genai.GenerativeModel(
        model_name=MODEL_NAME,
        system_instruction=system_instruction,
    )


def _extract_json(text: str):
    """Best-effort extraction of a JSON object/array from a model response,
    even if it's wrapped in markdown code fences."""
    cleaned = text.strip()
    cleaned = re.sub(r"^```json\s*|^```\s*|```$", "", cleaned, flags=re.MULTILINE).strip()
    # Try direct parse first
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        pass
    # Fall back to grabbing the first {...} or [...] block
    match = re.search(r"(\{.*\}|\[.*\])", cleaned, re.DOTALL)
    if match:
        return json.loads(match.group(1))
    raise GeminiServiceError("AI response was not valid JSON.")


def _call_gemini(prompt: str, system_instruction: str = SYSTEM_INSTRUCTION) -> str:
    try:
        model = _get_model(system_instruction)
        response = model.generate_content(prompt)
        if not response or not getattr(response, "text", None):
            raise GeminiServiceError("AI Assistant is temporarily unavailable. Please try again.")
        return response.text
    except GeminiServiceError:
        raise
    except Exception as exc:  # covers API errors, rate limits, network errors
        raise GeminiServiceError(
            "AI Assistant is temporarily unavailable. Please try again."
        ) from exc


def chat_reply(history: list, user_message: str, context_text: str = None) -> str:
    """
    Generate a chat reply given prior conversation turns.
    `history` is a list of {"role": "user"/"assistant", "content": str}.
    `context_text` (optional) is extracted document text to ground the answer in.
    """
    convo_lines = []
    for turn in history[-20:]:  # keep prompt size reasonable
        speaker = "Student" if turn["role"] == "user" else "Assistant"
        convo_lines.append(f"{speaker}: {turn['content']}")

    context_block = ""
    if context_text:
        # Trim very long documents to a reasonable context window
        trimmed = context_text[:12000]
        context_block = (
            "\n\nThe student has uploaded a study document. Use the following "
            "extracted content as the primary source when answering, and say so "
            "if the answer isn't found in it:\n---\n" + trimmed + "\n---\n"
        )

    prompt = (
        f"{context_block}\n"
        f"Conversation so far:\n{chr(10).join(convo_lines)}\n\n"
        f"Student: {user_message}\nAssistant:"
    )
    return _call_gemini(prompt)


def summarize_text(text: str, length: str = "medium") -> str:
    style_map = {
        "short": "a very short summary (3-5 sentences)",
        "medium": "a medium-length summary (2-3 paragraphs) covering the main ideas",
        "detailed": "a detailed, thorough summary covering all important points and sub-topics",
        "bullet": "clean bullet-point notes covering key concepts, definitions and important points",
        "exam": "concise exam-revision notes: key terms, definitions, formulas (if any), and the most exam-relevant points",
    }
    style = style_map.get(length, style_map["medium"])
    prompt = (
        f"Summarize the following study material as {style}. "
        f"Preserve important terminology, key definitions, and formulas where relevant. "
        f"Use clear headings and formatting.\n\n---\n{text[:15000]}\n---"
    )
    return _call_gemini(prompt)


def generate_questions(topic_or_text: str, difficulty: str, num_questions: int, question_type: str) -> list:
    """Returns a list of question dicts (structure depends on question_type)."""
    type_instructions = {
        "mcq": (
            "Generate multiple-choice questions. Each item must be a JSON object with keys: "
            '"question" (string), "options" (array of exactly 4 strings), '
            '"correct_answer" (must exactly match one of the options), "explanation" (string).'
        ),
        "short": (
            'Generate short-answer questions. Each item: "question" (string), '
            '"model_answer" (short answer string), "explanation" (key points, string).'
        ),
        "long": (
            'Generate long-answer/essay questions. Each item: "question" (string), '
            '"model_answer" (a structured full answer string), "explanation" (key points, string).'
        ),
        "truefalse": (
            'Generate true/false questions. Each item: "question" (string), '
            '"correct_answer" ("True" or "False"), "explanation" (string).'
        ),
        "mixed": (
            "Generate a mix of MCQ, short-answer and true/false questions. Each item must include "
            '"question", "type" (one of "mcq","short","truefalse"), "options" (array, only for mcq, else null), '
            '"correct_answer" (or "model_answer" for short type), "explanation".'
        ),
    }
    instruction = type_instructions.get(question_type, type_instructions["mcq"])

    prompt = (
        f"You are creating exam practice questions for a college student on the topic/material below.\n"
        f"Difficulty: {difficulty}\n"
        f"Number of questions: {num_questions}\n"
        f"{instruction}\n"
        f"Respond ONLY with a valid JSON array of {num_questions} question objects. "
        f"No markdown, no commentary, no code fences — just the raw JSON array.\n\n"
        f"Topic/Material:\n---\n{topic_or_text[:12000]}\n---"
    )
    raw = _call_gemini(prompt)
    data = _extract_json(raw)
    if not isinstance(data, list):
        raise GeminiServiceError("AI did not return a valid question list.")
    return data


def generate_quiz(topic_or_text: str, difficulty: str, num_questions: int) -> list:
    """Always returns MCQ-style questions suitable for the interactive quiz mode."""
    prompt = (
        f"Create a multiple-choice quiz for a college student.\n"
        f"Topic/Material below. Difficulty: {difficulty}. Number of questions: {num_questions}.\n"
        f'Respond ONLY with a JSON array. Each item: "question" (string), '
        f'"options" (array of exactly 4 strings), "correct_answer" (must exactly match one option), '
        f'"explanation" (short string explaining the correct answer). '
        f"No markdown, no commentary, no code fences — just the raw JSON array.\n\n"
        f"Topic/Material:\n---\n{topic_or_text[:12000]}\n---"
    )
    raw = _call_gemini(prompt)
    data = _extract_json(raw)
    if not isinstance(data, list):
        raise GeminiServiceError("AI did not return a valid quiz.")
    return data
